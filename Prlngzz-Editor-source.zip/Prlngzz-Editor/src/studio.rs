//! Native Prlngzz profile documents and loss-aware Fleasion compatibility.
//!
//! The editor stores the source JSON as `serde_json::Value` so fields it does
//! not yet understand survive a save/export cycle. Known rule fields are
//! normalized into the native schema; original Fleasion objects are retained
//! under `legacy` for fields that have no native equivalent yet.

use anyhow::{bail, ensure, Context, Result};
use serde_json::{json, Map, Value};
use std::collections::HashSet;
use std::path::Path;

pub const FORMAT: &str = "prlngzz-editor";
pub const SCHEMA_VERSION: u32 = 1;

#[derive(Clone, Debug)]
pub struct ProfileDocument {
    raw: Value,
}

#[derive(Clone, Debug, Default)]
pub struct ValidationReport {
    pub errors: Vec<String>,
    pub warnings: Vec<String>,
    pub rules: usize,
    pub enabled_rules: usize,
    pub targets: usize,
}

impl ProfileDocument {
    pub fn new(name: &str, game: &str) -> Self {
        Self {
            raw: json!({
                "format": FORMAT,
                "schema_version": SCHEMA_VERSION,
                "profile": {
                    "name": name,
                    "game": game,
                    "description": ""
                },
                "rules": []
            }),
        }
    }

    pub fn parse_native(text: &str) -> Result<Self> {
        let raw: Value = serde_json::from_str(text.trim_start_matches('\u{feff}'))
            .context("The profile is not valid JSON")?;
        let object = raw.as_object().context("A native profile must be a JSON object")?;
        ensure!(object.get("format").and_then(Value::as_str) == Some(FORMAT), "This is not a Prlngzz Editor profile");
        let version = object.get("schema_version").and_then(Value::as_u64).context("The profile has no valid schema_version")?;
        ensure!(version >= 1, "The profile schema_version must be at least 1");
        ensure!(version <= u64::from(SCHEMA_VERSION), "This profile uses a newer schema version ({version}); update Prlngzz Editor before editing it");
        ensure!(object.get("rules").is_some_and(Value::is_array), "The profile rules field must be an array");
        ensure!(object.get("profile").is_some_and(Value::is_object), "The profile metadata field must be an object");
        Ok(Self { raw })
    }

    /// Import the Fleasion object/list representation, preserving root, rule,
    /// and group fields that do not have a native equivalent yet.
    pub fn import_fleasion(text: &str) -> Result<Self> {
        let source: Value = serde_json::from_str(text.trim_start_matches('\u{feff}'))
            .context("The Fleasion configuration is not valid JSON")?;
        let (rules, mut legacy_root) = match &source {
            Value::Array(items) => (items, Map::new()),
            Value::Object(object) => {
                let items = object.get("replacement_rules").and_then(Value::as_array)
                    .context("The Fleasion configuration has no replacement_rules array")?;
                let mut extra = object.clone();
                extra.remove("replacement_rules");
                (items, extra)
            }
            _ => bail!("A Fleasion configuration must be a JSON object or list"),
        };

        let mut index = 0usize;
        let converted = rules.iter().map(|node| import_node(node, &mut index)).collect::<Vec<_>>();
        let profile_name = legacy_root.remove("name").and_then(|v| v.as_str().map(str::to_owned)).unwrap_or_else(|| "Imported configuration".to_owned());
        let description = legacy_root.remove("description").and_then(|v| v.as_str().map(str::to_owned)).unwrap_or_default();
        let game = legacy_root.remove("game").and_then(|v| v.as_str().map(str::to_owned)).unwrap_or_else(|| "RIVALS".to_owned());

        let mut raw = json!({
            "format": FORMAT,
            "schema_version": SCHEMA_VERSION,
            "profile": { "name": profile_name, "game": game, "description": description },
            "rules": converted,
            "legacy_root": Value::Object(legacy_root),
            "compatibility": { "imported_from": "Fleasion-compatible JSON" }
        });
        if let Some(map) = raw.as_object_mut() {
            // Retain whether the source used a bare list, for diagnostics and round-trip context.
            map.insert("legacy_was_array".into(), Value::Bool(source.is_array()));
        }
        Ok(Self { raw })
    }

    pub fn from_path(path: &Path) -> Result<Self> {
        let text = std::fs::read_to_string(path).with_context(|| format!("Reading {}", path.display()))?;
        let native = serde_json::from_str::<Value>(text.trim_start_matches('\u{feff}')).ok().is_some_and(|value| {
            value.get("format").and_then(Value::as_str) == Some(FORMAT)
        });
        if native {
            Self::parse_native(&text)
        } else {
            Self::import_fleasion(&text)
        }
    }

    pub fn to_native_json(&self) -> Result<String> {
        serde_json::to_string_pretty(&self.raw).context("Serializing the Prlngzz profile")
    }

    pub fn to_fleasion_json(&self) -> Result<String> {
        let mut root = self.raw.get("legacy_root").and_then(Value::as_object).cloned().unwrap_or_default();
        let rules = self.raw.get("rules").and_then(Value::as_array).context("The profile rules field must be an array")?;
        root.insert("replacement_rules".into(), Value::Array(rules.iter().map(export_node).collect()));
        // Standard profile metadata is surfaced in the legacy file too.
        if let Some(profile) = self.raw.get("profile").and_then(Value::as_object) {
            for key in ["name", "game", "description"] {
                if let Some(value) = profile.get(key) {
                    root.insert(key.to_owned(), value.clone());
                }
            }
        }
        serde_json::to_string_pretty(&Value::Object(root)).context("Serializing Fleasion-compatible JSON")
    }

    pub fn name(&self) -> &str {
        self.raw.pointer("/profile/name").and_then(Value::as_str).unwrap_or("Untitled configuration")
    }

    pub fn game(&self) -> &str {
        self.raw.pointer("/profile/game").and_then(Value::as_str).unwrap_or("RIVALS")
    }

    pub fn description(&self) -> &str {
        self.raw.pointer("/profile/description").and_then(Value::as_str).unwrap_or("")
    }

    pub fn set_metadata(&mut self, name: &str, game: &str, description: &str) {
        if let Some(profile) = self.raw.get_mut("profile").and_then(Value::as_object_mut) {
            profile.insert("name".into(), Value::String(name.to_owned()));
            profile.insert("game".into(), Value::String(game.to_owned()));
            profile.insert("description".into(), Value::String(description.to_owned()));
        }
    }

    pub fn rules(&self) -> &[Value] {
        self.raw.get("rules").and_then(Value::as_array).map(Vec::as_slice).unwrap_or(&[])
    }

    pub fn add_rule(&mut self, target_id: u64, replacement_id: u64) -> Result<()> {
        ensure!(target_id > 0 && replacement_id > 0, "Asset IDs must be greater than zero");
        let rules = self.raw.get_mut("rules").and_then(Value::as_array_mut).context("The profile rules field must be an array")?;
        let mut sequence = count_rules(rules) + 1;
        while rule_id_exists(rules, &format!("rule-{sequence:03}")) { sequence += 1; }
        rules.push(json!({
            "id": format!("rule-{sequence:03}"),
            "name": "Asset replacement",
            "enabled": true,
            "targets": [target_id],
            "action": { "type": "asset_id", "asset_id": replacement_id },
            "notes": ""
        }));
        Ok(())
    }

    /// Adds a local replacement to an ordinary Roblox asset ID or a 32-hex cache entry ID.
    pub fn add_local_rule(&mut self, target: &str, path: &str) -> Result<()> {
        ensure!(self.game().trim().eq_ignore_ascii_case("RIVALS"), "Local replacements are available for RIVALS profiles only");
        ensure!(!path.trim().is_empty(), "Choose a local replacement file");
        let target = target.trim();
        let target = match target.parse::<u64>() {
            Ok(id) if id > 0 => json!(id),
            _ => {
                ensure!(target.len() == 32 && target.bytes().all(|b| b.is_ascii_hexdigit()),
                    "Target must be a positive Roblox asset ID or a 32-character cache entry ID");
                json!(target.to_ascii_lowercase())
            }
        };
        let rules = self.raw.get_mut("rules").and_then(Value::as_array_mut).context("The profile rules field must be an array")?;
        let mut sequence = count_rules(rules) + 1;
        while rule_id_exists(rules, &format!("rule-{sequence:03}")) { sequence += 1; }
        rules.push(json!({
            "id": format!("rule-{sequence:03}"),
            "name": "Local file replacement",
            "enabled": true,
            "targets": [target],
            "action": { "type": "local_file", "path": path },
            "notes": "Local cache replacement; OBJ geometry is converted to Roblox mesh v1 for mesh targets."
        }));
        Ok(())
    }

    pub fn remove_rule(&mut self, index: usize) -> bool {
        self.raw.get_mut("rules").and_then(Value::as_array_mut).is_some_and(|rules| {
            if index < rules.len() { rules.remove(index); true } else { false }
        })
    }

    pub fn set_rule_enabled(&mut self, index: usize, enabled: bool) -> bool {
        let Some(rule) = self.raw.get_mut("rules").and_then(Value::as_array_mut).and_then(|v| v.get_mut(index)) else { return false; };
        rule.as_object_mut().is_some_and(|object| {
            object.insert("enabled".into(), Value::Bool(enabled));
            true
        })
    }

    pub fn validation(&self) -> ValidationReport {
        let mut report = ValidationReport::default();
        if self.name().trim().is_empty() { report.errors.push("Profile name is empty".into()); }
        let Some(rules) = self.raw.get("rules").and_then(Value::as_array) else {
            report.errors.push("Rules must be an array".into());
            return report;
        };
        let mut rule_ids = HashSet::new();
        validate_nodes(rules, &mut report, &mut rule_ids);
        report
    }
}

fn import_node(node: &Value, index: &mut usize) -> Value {
    let Some(object) = node.as_object() else {
        *index += 1;
        return json!({
            "id": format!("rule-{:03}", *index),
            "name": "Unsupported entry",
            "enabled": false,
            "targets": [],
            "action": { "type": "unsupported", "source_value": node },
            "notes": "This source entry is not an object; it was retained for compatibility."
        });
    };
    if object.get("type").and_then(Value::as_str) == Some("group") {
        let children = object.get("children").and_then(Value::as_array).map(|items| items.iter().map(|v| import_node(v, index)).collect()).unwrap_or_default();
        return json!({
            "type": "group",
            "id": object.get("id").and_then(Value::as_str).unwrap_or("group-imported"),
            "name": object.get("name").and_then(Value::as_str).unwrap_or("Imported group"),
            "enabled": object.get("enabled").and_then(Value::as_bool).unwrap_or(true),
            "children": children,
            "legacy": node
        });
    }

    *index += 1;
    let mode = object.get("mode").and_then(Value::as_str).map(str::to_ascii_lowercase)
        .or_else(|| object.get("remove").and_then(Value::as_bool).filter(|v| *v).map(|_| "remove".to_owned()))
        .unwrap_or_else(|| "id".to_owned());
    let action = match mode.as_str() {
        "remove" => json!({ "type": "remove" }),
        "local" => match object.get("local_path").and_then(Value::as_str).filter(|p| !p.trim().is_empty()) {
            Some(path) => json!({ "type": "local_file", "path": path }),
            None => json!({ "type": "remove" }),
        },
        "cdn" => {
            let url = object.get("cdn_url").and_then(Value::as_str).unwrap_or("");
            if url.starts_with("https://") {
                json!({ "type": "https", "url": url })
            } else if let Some(path) = url.strip_prefix("file:///") {
                json!({ "type": "local_file", "path": path })
            } else if url.trim().is_empty() {
                json!({ "type": "remove" })
            } else if url.contains("://") {
                json!({ "type": "unsupported", "source_mode": mode, "source_value": object.get("cdn_url").cloned().unwrap_or(Value::Null) })
            } else {
                // Older Fleasion files sometimes put a local filesystem path in
                // `cdn_url`; the cache parser treats those values as local files.
                json!({ "type": "local_file", "path": url })
            }
        }
        "id" => match object.get("with_id") {
            None | Some(Value::Null) => json!({ "type": "remove" }),
            Some(Value::String(value)) if value.trim().is_empty() => json!({ "type": "remove" }),
            Some(value) => match as_positive_u64(value) {
                Some(asset_id) if asset_id > 1 => json!({ "type": "asset_id", "asset_id": asset_id }),
                // Fleasion treats 0/1 as placeholder IDs that do not apply.
                // Keep those original records intact rather than turning them into removes.
                _ => json!({ "type": "unsupported", "source_mode": mode, "source_value": value }),
            },
        },
        _ => json!({ "type": "unsupported", "source_mode": mode }),
    };
    json!({
        "id": format!("rule-{:03}", *index),
        "name": object.get("name").and_then(Value::as_str).unwrap_or("Imported rule"),
        "enabled": object.get("enabled").and_then(Value::as_bool).unwrap_or(true),
        "targets": object.get("replace_ids").and_then(Value::as_array).cloned().unwrap_or_default(),
        "action": action,
        "notes": "",
        "legacy": node
    })
}

fn export_node(node: &Value) -> Value {
    let Some(object) = node.as_object() else { return node.clone(); };
    if object.get("type").and_then(Value::as_str) == Some("group") {
        let mut legacy = object.get("legacy").and_then(Value::as_object).cloned().unwrap_or_default();
        legacy.insert("type".into(), Value::String("group".into()));
        legacy.insert("name".into(), object.get("name").cloned().unwrap_or_else(|| json!("Group")));
        legacy.insert("enabled".into(), object.get("enabled").cloned().unwrap_or(Value::Bool(true)));
        let children = object.get("children").and_then(Value::as_array)
            .map(|items| items.iter().map(export_node).collect::<Vec<_>>())
            .unwrap_or_default();
        legacy.insert("children".into(), Value::Array(children));
        return Value::Object(legacy);
    }

    let mut legacy = object.get("legacy").and_then(Value::as_object).cloned().unwrap_or_default();
    legacy.insert("name".into(), object.get("name").cloned().unwrap_or_else(|| json!("Rule")));
    legacy.insert("enabled".into(), object.get("enabled").cloned().unwrap_or(Value::Bool(true)));
    legacy.insert("replace_ids".into(), object.get("targets").cloned().unwrap_or_else(|| json!([])));
    for key in ["mode", "with_id", "local_path", "cdn_url", "remove"] { legacy.remove(key); }
    match object.get("action").and_then(Value::as_object).and_then(|a| a.get("type")).and_then(Value::as_str).unwrap_or("unsupported") {
        "remove" => { legacy.insert("mode".into(), json!("remove")); }
        "asset_id" => {
            legacy.insert("mode".into(), json!("id"));
            if let Some(id) = object.pointer("/action/asset_id") { legacy.insert("with_id".into(), id.clone()); }
        }
        "local_file" => {
            legacy.insert("mode".into(), json!("local"));
            if let Some(path) = object.pointer("/action/path") { legacy.insert("local_path".into(), path.clone()); }
        }
        "https" => {
            legacy.insert("mode".into(), json!("cdn"));
            if let Some(url) = object.pointer("/action/url") { legacy.insert("cdn_url".into(), url.clone()); }
        }
        _ => {
            // Preserve unsupported source-specific syntax, but carry across the
            // editable common fields so toggles/renames are not silently lost.
            if let Some(original) = object.get("legacy").and_then(Value::as_object) {
                let mut preserved = original.clone();
                preserved.insert("name".into(), object.get("name").cloned().unwrap_or_else(|| json!("Rule")));
                preserved.insert("enabled".into(), object.get("enabled").cloned().unwrap_or(Value::Bool(true)));
                preserved.insert("replace_ids".into(), object.get("targets").cloned().unwrap_or_else(|| json!([])));
                return Value::Object(preserved);
            }
            legacy.insert("mode".into(), json!("unsupported"));
        }
    }
    Value::Object(legacy)
}


fn rule_id_exists(nodes: &[Value], id: &str) -> bool {
    nodes.iter().any(|node| {
        node.get("id").and_then(Value::as_str) == Some(id)
            || node.get("children").and_then(Value::as_array).is_some_and(|children| rule_id_exists(children, id))
    })
}

fn count_rules(nodes: &[Value]) -> usize {
    nodes.iter().map(|node| {
        if node.get("type").and_then(Value::as_str) == Some("group") {
            node.get("children").and_then(Value::as_array).map_or(0, |children| count_rules(children))
        } else { 1 }
    }).sum()
}

fn validate_nodes(nodes: &[Value], report: &mut ValidationReport, ids: &mut HashSet<String>) {
    for node in nodes {
        let Some(object) = node.as_object() else {
            report.errors.push("A rule or group is not an object".into());
            continue;
        };
        if object.get("type").and_then(Value::as_str) == Some("group") {
            if let Some(children) = object.get("children").and_then(Value::as_array) { validate_nodes(children, report, ids); }
            else { report.errors.push("A group has no children array".into()); }
            continue;
        }
        report.rules += 1;
        let enabled = object.get("enabled").and_then(Value::as_bool).unwrap_or(true);
        if enabled { report.enabled_rules += 1; }
        if let Some(id) = object.get("id").and_then(Value::as_str) {
            if !ids.insert(id.to_owned()) { report.errors.push(format!("Duplicate rule ID: {id}")); }
        } else { report.errors.push("A rule has no stable ID".into()); }
        let targets = object.get("targets").and_then(Value::as_array);
        if let Some(targets) = targets {
            report.targets += targets.len();
            let mut seen = HashSet::new();
            for target in targets {
                if let Some(value) = as_positive_u64(target) {
                    if !seen.insert(value) { report.warnings.push(format!("Rule {} contains duplicate target ID {value}", object.get("name").and_then(Value::as_str).unwrap_or("(unnamed)"))); }
                } else if target.as_str().is_some_and(|text| text.contains(':')) {
                    report.warnings.push(format!("Target selector '{}' is preserved but cannot be mapped to an ordinary cache asset ID", target.as_str().unwrap_or_default()));
                } else if !target.is_string() {
                    report.warnings.push("A target is not a positive asset ID or compatibility selector".into());
                }
            }
        } else { report.errors.push("A rule has no targets array".into()); }
        match object.pointer("/action/type").and_then(Value::as_str) {
            Some("asset_id") if object.pointer("/action/asset_id").and_then(as_positive_u64).is_some() => {}
            Some("local_file") if object.pointer("/action/path").and_then(Value::as_str).is_some_and(|v| !v.trim().is_empty()) => {}
            Some("https") if object.pointer("/action/url").and_then(Value::as_str).is_some_and(|v| v.starts_with("https://")) => {}
            Some("remove") => {}
            Some("unsupported") | None => report.warnings.push(format!("Rule {} uses an unsupported action", object.get("name").and_then(Value::as_str).unwrap_or("(unnamed)"))),
            Some(other) => report.errors.push(format!("Rule {} has an incomplete or unknown action '{other}'", object.get("name").and_then(Value::as_str).unwrap_or("(unnamed)"))),
        }
    }
}

fn as_positive_u64(value: &Value) -> Option<u64> {
    match value {
        Value::Number(number) => number.as_u64().filter(|v| *v > 0),
        Value::String(text) => text.trim().parse::<u64>().ok().filter(|v| *v > 0),
        _ => None,
    }
}

/// Parse one or more numeric asset IDs from whitespace/comma/newline separated
/// input or recognizable Roblox asset URLs. Results are unique and preserve order.
pub fn extract_asset_ids(input: &str) -> Vec<u64> {
    let mut found = Vec::new();
    for part in input.split(|c: char| !c.is_ascii_digit()) {
        if part.is_empty() { continue; }
        if let Ok(id) = part.parse::<u64>() {
            if id > 0 && !found.contains(&id) { found.push(id); }
        }
    }
    found
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config;

    #[test]
    fn adding_rules_after_removal_does_not_reuse_an_existing_rule_id() {
        let mut profile = ProfileDocument::new("IDs", "RIVALS");
        profile.add_rule(10, 20).unwrap();
        profile.add_rule(11, 21).unwrap();
        profile.add_rule(12, 22).unwrap();
        profile.remove_rule(1);
        profile.add_rule(13, 23).unwrap();
        assert!(profile.validation().errors.is_empty());
    }

    #[test]
    fn parses_multiple_ids_and_roblox_asset_urls() {
        assert_eq!(extract_asset_ids("123, 456\nhttps://www.roblox.com/library/789/example"), [123, 456, 789]);
        assert_eq!(extract_asset_ids("rbxassetid://42 42 0"), [42]);
    }

    #[test]
    fn creates_and_round_trips_native_profile() {
        let mut profile = ProfileDocument::new("RIVALS base", "RIVALS");
        profile.add_rule(123, 456).unwrap();
        let encoded = profile.to_native_json().unwrap();
        let decoded = ProfileDocument::parse_native(&encoded).unwrap();
        assert_eq!(decoded.name(), "RIVALS base");
        assert_eq!(decoded.validation().rules, 1);
    }

    #[test]
    fn imports_nested_fleasion_rules_and_exports_compatible_json() {
        let legacy = r#"{
            "replacement_rules": [{"type":"group","name":"Weapons","enabled":true,"children":[
              {"name":"Skin","replace_ids":[123],"mode":"id","with_id":456,"custom_field":{"keep":true}},
              {"name":"Remove","replace_ids":[789],"remove":true}
            ]}], "source":"community", "custom_root":17
        }"#;
        let profile = ProfileDocument::import_fleasion(legacy).unwrap();
        assert_eq!(profile.validation().rules, 2);
        let back = profile.to_fleasion_json().unwrap();
        let value: Value = serde_json::from_str(&back).unwrap();
        assert_eq!(value["source"], "community");
        assert_eq!(value["custom_root"], 17);
        assert_eq!(value["replacement_rules"][0]["children"][0]["custom_field"]["keep"], true);
        assert_eq!(config::parse(&back, Path::new(".")).unwrap().len(), 2);
    }

    #[test]
    fn cdn_mode_with_a_local_path_is_imported_as_a_local_file() {
        let legacy = r#"[{"name":"local legacy","replace_ids":[123],"mode":"cdn","cdn_url":"C:\\assets\\replacement.png"}]"#;
        let profile = ProfileDocument::import_fleasion(legacy).unwrap();
        assert_eq!(profile.rules()[0]["action"]["type"], "local_file");
        assert_eq!(profile.rules()[0]["action"]["path"], "C:\\assets\\replacement.png");
    }

    #[test]
    fn unsupported_legacy_modes_are_not_exported_as_destructive_rules() {
        let legacy = r#"[{"name":"slot","replace_ids":["123:1"],"mode":"texturepack"}]"#;
        let profile = ProfileDocument::import_fleasion(legacy).unwrap();
        let back: Value = serde_json::from_str(&profile.to_fleasion_json().unwrap()).unwrap();
        let rule = &back["replacement_rules"][0];
        assert_eq!(rule["mode"], "texturepack");
        assert_eq!(rule["replace_ids"][0], "123:1");
    }

    #[test]
    fn unsupported_legacy_rules_preserve_source_fields_and_editor_changes() {
        let legacy = r#"[{"name":"slot","replace_ids":["123:1"],"mode":"texturepack","custom":"retained"}]"#;
        let mut profile = ProfileDocument::import_fleasion(legacy).unwrap();
        assert!(profile.set_rule_enabled(0, false));
        let exported: Value = serde_json::from_str(&profile.to_fleasion_json().unwrap()).unwrap();
        let rule = &exported["replacement_rules"][0];
        assert_eq!(rule["mode"], "texturepack");
        assert_eq!(rule["replace_ids"][0], "123:1");
        assert_eq!(rule["custom"], "retained");
        assert_eq!(rule["enabled"], false);
    }

    #[test]
    fn empty_id_replacement_means_remove_but_placeholder_is_preserved() {
        let legacy = r#"[
            {"replace_ids":[123],"mode":"id","with_id":""},
            {"replace_ids":[456],"mode":"id","with_id":1}
        ]"#;
        let profile = ProfileDocument::import_fleasion(legacy).unwrap();
        assert_eq!(profile.rules()[0]["action"]["type"], "remove");
        assert_eq!(profile.rules()[1]["action"]["type"], "unsupported");
        let exported: Value = serde_json::from_str(&profile.to_fleasion_json().unwrap()).unwrap();
        assert_eq!(exported["replacement_rules"][1]["with_id"], 1);
    }

    #[test]
    fn duplicate_rule_ids_and_invalid_actions_are_reported() {
        let text = r#"{"format":"prlngzz-editor","schema_version":1,"profile":{"name":"x"},"rules":[
            {"id":"same","targets":[1],"enabled":true,"action":{"type":"remove"}},
            {"id":"same","targets":[2],"enabled":true,"action":{"type":"unknown"}}
        ]}"#;
        let profile = ProfileDocument::parse_native(text).unwrap();
        let report = profile.validation();
        assert!(!report.errors.is_empty());
        assert!(!report.warnings.is_empty());
    }
}

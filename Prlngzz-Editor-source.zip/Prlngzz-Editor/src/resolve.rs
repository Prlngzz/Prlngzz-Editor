//! Working out which cached entries belong to which Roblox asset ID.
//!
//! Asset fingerprints are resolved through anonymous public asset delivery.
//! Private or permission-restricted assets are left unresolved; this module
//! never stores or transmits session credentials.

use crate::config::{fingerprint, Fingerprint, IdMap};
use crate::format;
use crate::store::{Entry, Store};
use crate::texture;
use anyhow::{Context, Result};
use std::collections::{HashMap, HashSet};
use std::io::Read;
use std::time::Duration;

/// The rendition list the client sends for images: KTX2 first.
const KTX2_FIRST: &str = "W3siZm9ybWF0Ijoia3R4MiIsIm1ham9yVmVyc2lvbiI6IjgiLCJmaWRlbGl0eSI6Ii8vLy8vQUU9In0seyJmb3JtYXQiOiJrdHgyIiwibWFqb3JWZXJzaW9uIjoiN3JkbyIsImZpZGVsaXR5IjoiLy8vLy9BRT0ifV0%3D";
/// Largest asset that is downloaded.
const LIMIT: u64 = 256 << 20;
/// Requests made at the same time.
const WORKERS: usize = 8;

pub enum Fetched {
    Body(Vec<u8>),
    Denied(u16),
    Gone,
}

/// Downloads an asset by ID using anonymous public delivery only.
pub fn fetch(id: u64, ktx2: bool) -> Result<Fetched> {
    let mut url = format!("https://assetdelivery.roblox.com/v1/asset/?id={id}");
    if ktx2 {
        url.push_str("&contentRepresentationPriorityList=");
        url.push_str(KTX2_FIRST);
    }
    let request = ureq::get(&url)
        .set("User-Agent", "Prlngzz-Editor")
        .timeout(Duration::from_secs(40));
    match request.call() {
        Ok(response) => {
            let mut body = Vec::new();
            response.into_reader().take(LIMIT + 1).read_to_end(&mut body)
                .with_context(|| format!("downloading asset {id}"))?;
            anyhow::ensure!(body.len() as u64 <= LIMIT, "asset {id} is larger than {} MB", LIMIT >> 20);
            Ok(Fetched::Body(body))
        }
        Err(ureq::Error::Status(code @ (401 | 403), _)) => Ok(Fetched::Denied(code)),
        Err(ureq::Error::Status(400 | 404, _)) => Ok(Fetched::Gone),
        Err(e) => Err(e).with_context(|| format!("looking up asset {id}")),
    }
}

#[derive(Clone, Debug, PartialEq)]
pub enum Outcome {
    /// Already in the ID map and present in the cache.
    Known,
    /// The public download is byte-for-byte a cached entry.
    Exact,
    /// A KTX2 pack of the image is cached.
    Rendition,
    /// Fetched, but nothing in the cache matches. It will match once Roblox downloads it.
    NotCached,
    Denied(u16),
    Gone,
    Failed(String),
}

impl Outcome {
    /// True when the asset is tied to at least one cached entry.
    pub fn matched(&self) -> bool {
        matches!(self, Outcome::Known | Outcome::Exact | Outcome::Rendition)
    }
}

impl std::fmt::Display for Outcome {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Outcome::Known => write!(f, "already known"),
            Outcome::Exact => write!(f, "matched exactly"),
            Outcome::Rendition => write!(f, "matched its texture packs"),
            Outcome::NotCached => write!(f, "not in the cache yet"),
            Outcome::Denied(401) => write!(f, "not publicly accessible (HTTP 401)"),
            Outcome::Denied(_) => write!(f, "not publicly accessible"),
            Outcome::Gone => write!(f, "no such asset"),
            Outcome::Failed(e) => write!(f, "lookup failed: {e}"),
        }
    }
}

/// Runs `job` over `items` on a few threads, reporting how many are done.
fn parallel<T: Sync, R: Send>(items: &[T], progress: &(dyn Fn(usize, usize) + Sync), job: impl Fn(&T) -> R + Sync) -> Vec<R> {
    let done = std::sync::atomic::AtomicUsize::new(0);
    let chunk = items.len().div_ceil(WORKERS).max(1);
    std::thread::scope(|scope| {
        let handles: Vec<_> = items
            .chunks(chunk)
            .map(|part| {
                let (job, done) = (&job, &done);
                scope.spawn(move || {
                    part.iter()
                        .map(|item| {
                            let result = job(item);
                            progress(done.fetch_add(1, std::sync::atomic::Ordering::Relaxed) + 1, items.len());
                            result
                        })
                        .collect::<Vec<R>>()
                })
            })
            .collect();
        handles.into_iter().flat_map(|h| h.join().expect("lookup thread panicked")).collect()
    })
}

/// Cached entries looked up by the fingerprint of their content.
struct Cache<'a> {
    store: &'a Store,
    entries: &'a [Entry],
    by_size: HashMap<u64, Vec<usize>>,
    md5s: HashMap<usize, String>,
    /// Content hashes of the cached texture packs; read when first needed.
    textures: Option<HashSet<String>>,
}

impl<'a> Cache<'a> {
    fn new(store: &'a Store, entries: &'a [Entry]) -> Self {
        let mut by_size: HashMap<u64, Vec<usize>> = HashMap::new();
        for (i, e) in entries.iter().enumerate() {
            if e.wrapped && !matches!(e.kind, "redirect" | "missing" | "empty") {
                by_size.entry(e.body_len).or_default().push(i);
            }
        }
        Self { store, entries, by_size, md5s: HashMap::new(), textures: None }
    }

    /// The entry holding exactly this content.
    fn find(&mut self, fp: &Fingerprint) -> Option<usize> {
        for &i in self.by_size.get(&fp.size)? {
            if !self.md5s.contains_key(&i) {
                let Ok(body) = self.store.read_body(&self.entries[i].id) else { continue };
                self.md5s.insert(i, fingerprint(&body).md5);
            }
            if self.md5s[&i] == fp.md5 {
                return Some(i);
            }
        }
        None
    }

    /// True when the cache has this content, or any pack of the texture it belongs to.
    fn holds(&mut self, fp: &Fingerprint) -> bool {
        if self.find(fp).is_some() {
            return true;
        }
        let Some(hash) = &fp.texture else { return false };
        let (store, entries) = (self.store, self.entries);
        self.textures.get_or_insert_with(|| entries.iter().filter_map(|e| texture::hash_of(store, e)).collect()).contains(hash)
    }

    /// The same fingerprint with its texture's content hash filled in, when it
    /// lacks one and the pack it describes is cached. Maps written before
    /// packs were understood are completed this way.
    fn completed(&mut self, fp: &Fingerprint) -> Option<Fingerprint> {
        if fp.texture.is_some() {
            return None;
        }
        let i = self.find(fp)?;
        let texture = texture::hash_of(self.store, &self.entries[i])?;
        Some(Fingerprint { texture: Some(texture), ..fp.clone() })
    }
}

/// Looks up `ids` and records in `idmap` which content each one has, so that
/// config rules naming them resolve to cached entries. `progress(done, total)`
/// follows the downloads. Returns what happened to each ID, in order.
///
/// An ID is only looked up once: the map remembers its fingerprints, and an
/// empty list for one that was refused or does not exist. `refresh` asks again
/// regardless, for when an asset was updated or made public.
pub fn identify(
    store: &Store,
    entries: &[Entry],
    idmap: &mut IdMap,
    ids: &[u64],
    refresh: bool,
    progress: &(dyn Fn(usize, usize) + Sync),
) -> Vec<(u64, Outcome)> {
    let mut cache = Cache::new(store, entries);
    let mut outcomes: HashMap<u64, Outcome> = HashMap::new();
    let mut unknown = Vec::new();
    for &id in ids {
        for fp in idmap.assets.get(&id.to_string()).cloned().unwrap_or_default() {
            if let Some(fp) = cache.completed(&fp) {
                idmap.add(id, fp);
            }
        }
        match idmap.assets.get(&id.to_string()).cloned() {
            Some(prints) if prints.iter().any(|fp| cache.holds(fp)) => drop(outcomes.insert(id, Outcome::Known)),
            Some(_) if refresh => unknown.push(id),
            // Looked up before: either its content is known and simply not cached, or it was refused.
            Some(prints) if prints.is_empty() => drop(outcomes.insert(id, Outcome::Denied(401))),
            Some(_) => drop(outcomes.insert(id, Outcome::NotCached)),
            None => unknown.push(id),
        }
    }

    let fetched = parallel(&unknown, progress, |&id| (id, fetch(id, false)));
    // Images are cached as the KTX2 packs the client asks for, not as the file
    // itself. Their fingerprint waits until the first pack has been asked for
    // too: recorded on its own it would mark the ID as looked up, and a pack
    // request that failed would never be made again.
    let mut images: Vec<(u64, Fingerprint)> = Vec::new();
    for (id, result) in fetched {
        let outcome = match result {
            Ok(Fetched::Body(body)) => {
                let fp = fingerprint(&body);
                if cache.holds(&fp) {
                    idmap.add(id, fp);
                    Outcome::Exact
                } else if format::is_image(format::sniff(&body)) {
                    images.push((id, fp));
                    continue;
                } else {
                    idmap.add(id, fp);
                    Outcome::NotCached
                }
            }
            Ok(Fetched::Denied(code)) => {
                idmap.assets.entry(id.to_string()).or_default();
                Outcome::Denied(code)
            }
            Ok(Fetched::Gone) => {
                idmap.assets.entry(id.to_string()).or_default();
                Outcome::Gone
            }
            Err(e) => Outcome::Failed(format!("{e:#}")),
        };
        outcomes.insert(id, outcome);
    }

    for ((id, original), result) in parallel(&images, &|_, _| {}, |(id, original)| ((*id, original.clone()), fetch(*id, true))) {
        let outcome = match result {
            Ok(Fetched::Body(body)) => {
                let pack = fingerprint(&body);
                let cached = cache.holds(&pack);
                idmap.add(id, original);
                idmap.add(id, pack);
                if cached {
                    Outcome::Rendition
                } else {
                    Outcome::NotCached
                }
            }
            // There is no pack to be had, so the file itself is all that can be known.
            Ok(Fetched::Denied(_) | Fetched::Gone) => {
                idmap.add(id, original);
                Outcome::NotCached
            }
            Err(e) => Outcome::Failed(format!("{e:#}")),
        };
        outcomes.insert(id, outcome);
    }
    ids.iter().map(|id| (*id, outcomes.get(id).cloned().unwrap_or(Outcome::NotCached))).collect()
}

/// One line saying how a lookup went overall.
pub fn summarize(outcomes: &[(u64, Outcome)]) -> String {
    let count = |test: fn(&Outcome) -> bool| outcomes.iter().filter(|(_, o)| test(o)).count();
    let mut parts =
        vec![format!("{} of {} matched to cached entries", count(Outcome::matched), format::count(outcomes.len(), "asset ID", "asset IDs"))];
    for (n, what) in [
        (count(|o| *o == Outcome::NotCached), "not in the cache yet"),
        (count(|o| matches!(o, Outcome::Denied(_))), "not publicly accessible"),
        (count(|o| *o == Outcome::Gone), "no longer exist"),
        (count(|o| matches!(o, Outcome::Failed(_))), "could not be looked up"),
    ] {
        if n > 0 {
            parts.push(format!("{n} {what}"));
        }
    }
    parts.join(", ")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn summary_counts_each_kind_of_outcome() {
        let outcomes = [(1, Outcome::Exact), (2, Outcome::Rendition), (3, Outcome::NotCached), (4, Outcome::Denied(401)), (5, Outcome::Denied(403))];
        assert_eq!(summarize(&outcomes), "2 of 5 asset IDs matched to cached entries, 1 not in the cache yet, 2 not publicly accessible");
        assert_eq!(summarize(&[(1, Outcome::Known)]), "1 of 1 asset ID matched to cached entries");
    }

    #[test]
    fn outcomes_read_as_plain_statements() {
        assert_eq!(Outcome::Denied(401).to_string(), "not publicly accessible (HTTP 401)");
        assert_eq!(Outcome::Denied(403).to_string(), "not publicly accessible");
        assert!(Outcome::Exact.matched() && Outcome::Known.matched() && !Outcome::NotCached.matched());
    }

}

# Prlngzz Editor

**Prlngzz Editor** is a Windows-first desktop workspace for managing Roblox asset-cache files and JSON replacement profiles. The application is built with Rust, `eframe` and `egui`, using the supplied rbxcache 1.1.1 implementation as its initial cache-engine foundation.

> **Development status:** this is an initial development build, not the completed product described in the project brief. The existing cache browser, preview, replacement, backup/restore and watcher systems are retained. The new Overview, RIVALS Workspace, Config Studio and Asset ID Editor are early functional implementations. See [Current implementation](#current-implementation) for what is and is not complete.

## Safety model

Prlngzz Editor operates on local Roblox cache files. It does not intercept HTTPS traffic, install certificates, collect Roblox passwords, store or send session cookies, extract tokens, inject DLLs, manipulate game memory, bypass anti-cheat systems, or automate gameplay. Asset lookups use anonymous public endpoints only; assets that Roblox does not make publicly available must be identified from local cache content or left unresolved.

Changes to a local cache are not a guarantee of an in-game result. Roblox may already have loaded an asset into memory, may download it again, or may not use the modified cache entry. Rejoining the experience may be necessary. Users remain responsible for following Roblox and experience-specific rules.

## Current implementation

### Retained cache engine

- Browse cached files in a searchable, sortable table, with filters for discovered content types.
- Preview supported images, KTX2 textures, meshes, models, animations, sounds, fonts and text assets.
- Export cached assets, including supported KTX2-to-PNG and mesh-to-OBJ conversions.
- Replace local cache entries from files or other cached entries.
- Import and apply Fleasion-style replacement JSON, including nested groups, `id`, `local`, `cdn`, `remove`, `replace_ids`, `with_id`, `local_path`, `cdn_url` and legacy `remove: true` syntax.
- Back up replaced originals and restore them when supported rules/configurations are disabled or removed.
- Monitor the local cache and re-apply enabled configurations to newly written assets.
- Resolve conflicts between simultaneously enabled replacement configurations.

### New Prlngzz Editor work

- Rebranded application/package identity and a dark purple/black theme.
- New sidebar navigation for Overview, RIVALS Workspace, Config Studio, Asset ID Editor, Asset Library, Game Library and Settings.
- Dedicated Overview and RIVALS pages.
- Native Prlngzz JSON document format (`format: prlngzz-editor`, schema version 1).
- Config Studio can create a profile, import native or Fleasion-compatible JSON, edit profile metadata, add/toggle/remove basic asset-ID replacement rules, validate rules, save native JSON, export Fleasion-compatible JSON, and stage a profile for cache preview/application.
- Asset ID Editor can paste multiple numeric IDs or Roblox asset URLs and add them as asset-ID replacement rules.
- Existing cache browser is surfaced as Asset Library; bundled presets form the offline Game Library baseline.
- Optional online preset manifests are disabled until the user supplies an HTTPS endpoint.

### Known limitations in this build

- The new visual editor does not yet expose all operations in the brief: advanced nested-group creation/reordering, rule renaming/descriptions, arbitrary replacement modes, local-file replacement selection in the ID editor, configuration collections and full CRUD profile management remain incomplete.
- The Asset Library currently reuses the retained cache browser. It does not yet provide all requested tagging, collection management, metadata editing or folder-import workflows.
- Game Library currently provides bundled presets and the retained pack workflow. A complete offline custom-game/preset manager and in-app catalog URL settings are not yet implemented.
- Fleasion texture-pack slot selectors (for example `assetId:slot`) and other proxy-specific rules are preserved as unsupported compatibility records. They are warned about rather than silently translated into ordinary cache asset IDs.
- Public-only asset fetching cannot resolve restricted/private sounds or other assets without public delivery. Users can tag a cached entry manually.
- Animation settings currently provide a simple on/off option; the requested full/reduced/minimal motion modes and per-component motion system are not all implemented.
- macOS and Linux are architectural future targets, not supported release builds yet.

## Build from source

Install a stable Rust toolchain with Cargo. On Windows, use the MSVC Rust target and Visual Studio C++ Build Tools.

```powershell
cargo build --release --locked
cargo test --release --locked
cargo clippy --all-targets --locked -- -D warnings
```

The executable is produced at:

```text
target/release/prlngzz-editor.exe
```

The Windows CI workflow copies it to the requested release filename:

```text
Prlngzz-Editor-Windows-x64.exe
```

The executable name is distinct from the Cargo package name. Running the app without arguments opens the graphical interface. `prlngzz-editor --help` lists the retained cache-management CLI commands.

## Configuration formats

### Fleasion-compatible JSON

The compatibility parser supports the common rule forms:

- `replacement_rules` at the root, or a root-level rule array.
- `replace_ids` targets and nested groups with `children`.
- `mode`: `id`, `local`, `cdn` or `remove`.
- `with_id`, `local_path` and `cdn_url` values.
- Legacy `remove: true` syntax.
- Rule and group `enabled` states.

Unsupported target selectors and source-specific modes are preserved in the native document under compatibility data. They are not applied as if they were ordinary asset IDs.

### Native Prlngzz JSON

A native profile starts with this structure:

```json
{
  "format": "prlngzz-editor",
  "schema_version": 1,
  "profile": {
    "name": "RIVALS Custom Pack",
    "game": "RIVALS",
    "description": "My custom configuration"
  },
  "rules": [
    {
      "id": "rule-001",
      "name": "Custom replacement",
      "enabled": true,
      "targets": [123456789],
      "action": {
        "type": "asset_id",
        "asset_id": 987654321
      },
      "notes": ""
    }
  ]
}
```

Unknown native fields and imported legacy rule data are retained by the document layer when they are not edited by the current UI. Schema versions newer than the app are refused to avoid writing a future document with an older schema implementation.

## Online catalog configuration

There is no hard-coded community catalog endpoint. To use an online catalog, set `PRLNGZZ_CATALOG_URL` to a trusted HTTPS manifest URL before starting the app. The manifest describes packs and may reference separate HTTPS JSON files. Downloaded data is parsed as configuration data only; scripts are never executed. Relative config paths are constrained to the manifest directory and path traversal is rejected.

Optional update and changelog endpoints are also environment-configured:

- `PRLNGZZ_RELEASE_API_URL`: HTTPS GitHub latest-release API endpoint.
- `PRLNGZZ_CHANGELOG_URL`: HTTPS changelog JSON endpoint.

When they are not set, no old project or maintainer endpoint is contacted.

## Local data

Application data is stored in the platform's standard per-user data directory under `Prlngzz Editor`. On first start, if the new directory does not exist and the prior `rbxcache` data directory is present, the app moves recoverable files such as cache backups, ID mappings, preferences and preset data into the new folder. It deliberately does **not** migrate or read the old `accounts.json`, because earlier versions could store Roblox session cookies there; that file is left in the legacy folder for the user to inspect or remove separately. Other files are left in place if a migration move fails.

## Windows CI and releases

`.github/workflows/windows.yml` runs formatting, tests, Clippy and the x64 Windows release build. It uploads `Prlngzz-Editor-Windows-x64.exe` as a workflow artifact. Pushing a `v<version>` tag that matches `Cargo.toml` also creates a GitHub Release with that executable attached.

The workflow is provided in this source package; it has not been run against a connected GitHub repository in this session. This environment also did not have `cargo`, `rustc` or `rustfmt` installed, so this source has **not** been compiled or tested here and no Windows executable is included. The workflow formats the sources, checks formatting, runs tests and Clippy, and only then builds the Windows binary.

## Credits and licensing

The cache engine in this project is derived from the user-supplied rbxcache 1.1.1 source. The user stated in the project brief that they have permission to reuse that source. The supplied archive did not contain a top-level license file, so the original author and redistribution terms must be confirmed and the correct license/attribution added before publishing binaries or source publicly. See [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).

Fleasion 2.4.1 was supplied as a compatibility reference. Its source archive includes a GPL-3.0 license; this implementation uses it as a reference for JSON behavior and does not copy its Python/Qt application source. Manrope font assets retain their OFL notice in `assets/Manrope-OFL.txt`.

# Third-party notices and source provenance

## rbxcache 1.1.1

The supplied rbxcache 1.1.1 archive is the source foundation for the cache browser, asset decoding, replacement, backup/restore, watcher and related systems retained in Prlngzz Editor. The project owner stated in the supplied brief that they have permission to reuse this source.

The uploaded archive did not contain a top-level `LICENSE`, `COPYING` or `NOTICE` file. Do not infer a license from the source's Rust dependencies or from the permission statement alone. Before redistributing this derivative publicly, confirm the original author's required copyright attribution and redistribution terms, then add the appropriate license and notices. Existing technical format identifiers and source comments have not been intentionally stripped.

## Fleasion 2.4.1

Fleasion 2.4.1 was inspected as a reference for legacy configuration syntax and behavior. Its supplied source archive includes a GPL-3.0 license. No Fleasion Python/Qt application source files are copied into this project. Names and JSON fields such as `replacement_rules`, `replace_ids`, `mode`, `with_id`, `local_path`, `cdn_url`, `children` and `remove` are retained for data-format compatibility.

## Manrope

The font asset is accompanied by `assets/Manrope-OFL.txt`, which carries the font's SIL Open Font License notice. Keep that notice with any redistribution of the font.
